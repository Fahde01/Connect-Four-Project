/*
Author: Ayomiposi Fadeni
Date: 15th of April, 2025
Description: This program imitates a connect four that has 2 players(Red and Yellow). each players
objective is to get four of their resprective colors in a row whether vertically, horizontally
and diagonally.Each player has a choice to make a more or quit. A player wins when they get four of their colors in a row (R or Y).
If not, they tie.
*/

#include <iostream>
#include <vector>

using namespace std;


vector<vector<char>> createBoard(){
    return vector<vector<char>>(6, vector<char>(7, '-'));
}

//Function to display game board
void displayBoard(const vector<vector<char>>& board) {
    for (const auto& row : board){
        for (const auto& cell : row){
            cout << cell << " ";
        }
        cout << endl;
    }

    cout << "=============\n";

    for (int i = 1; i <= 7; i++){
        cout << i << " ";
    }
    cout << endl;   
}

// Function to check if a play is valid or allowed
bool isValidPlay(const vector<vector<char>>& board, int column){
    if (column < 1 || column > 7){
        return false;
    }

    return board[0][column-1] == '-';
}

// Function to make a play
int playPiece(vector<vector<char>>& board, int column, char player){
    int col = column - 1;

    for (int row = 5; row >= 0; row--){
        if (board[row][col] == '-'){
            board[row][col] = player;
            return row;
        }
    }

    return -1;
}

// Function that checks if a player has won
bool checkWin(const vector<vector<char>>& board, int row, int col, char player){
    int count = 0;
    // for horizontal check
    for (int c = 0; c < 7; c++){
        if (board[row][c] == player){
            count++;
            if (count >= 4) return true;
        }
        else{
            count = 0;
        }
    }

    //for vertical check
    count = 0;
    for (int r = 0; r < 6; r++){
        if (board[r][col] == player){
            count++;
            if (count >= 4) return true;
        }
        else{
            count = 0;
        }
    }

    //for diagonal checks
    for (int r = 3; r < 6; r++){
        for (int c = 0; c < 4; c++){
            if (board[r][c] == player &&
                board[r-1][c+1] == player &&
                board[r-2][c+2] == player &&
                board[r-3][c+3] == player){
                    return true;
                }
        }
    }

    for (int r = 0; r < 3; r++){
        for (int c = 0; c < 4; c++){
            if (board[r][c] == player &&
                board[r+1][c+1] == player &&
                board[r+2][c+2] == player &&
                board[r+3][c+3] == player){
                    return true;
                }
        }
    }

    return false;
}

// Function to check if the board has been filled
bool isBoardFull(const vector<vector<char>>& board){
    for (const auto& row : board){
        for (const auto& cell : row){
            if (cell == '-'){
                return false;
            }
        }
    }
    return true;
}

// Function to play the game
void playGame(){
    auto board = createBoard();
    vector<char> players = {'R', 'Y'};
    vector<string> playerNames = {"Red", "Yellow"};
    int currentPlayer = 0;
    bool needToDisplayBoard = true;

    while (true){
        if (needToDisplayBoard) {
            displayBoard(board);
        }
        needToDisplayBoard = true;

        cout << "\nIt is " << playerNames[currentPlayer] << "'s turn." << endl;

        int column;
        cout << "In which column would you like to move (-1 to exit)? ";

        if (!(cin >> column)){  
            cout << "Invalid move, try again." << endl;
            needToDisplayBoard = false;
            continue;
        }

        if(column == -1){
            break;
        }

        if(!isValidPlay(board, column)){
            cout << "Invalid move, try again." << endl;
            needToDisplayBoard = false;
            continue;
        }

        int row = playPiece(board, column, players[currentPlayer]);
        
        if (checkWin(board, row, column-1, players[currentPlayer])) {
            displayBoard(board);
            cout << "\n" << playerNames[currentPlayer] << " wins!" << endl;
            break;
        }

        if (isBoardFull(board)){
            displayBoard(board);
            cout << "\nGame over. Tie game." << endl;
            break;
        }
        
        currentPlayer = 1 - currentPlayer;
    }
}


int main() 
{
    playGame();
    return 0;
}